package com.cg.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.Scanner;
import com.cg.bean.Customer;
import com.cg.service.CustomerServiceImpl;
import com.cg.service.ICustomerService;

public class KFCBank {
	
	public static void main(String[] args) {
		
		ICustomerService cser=new CustomerServiceImpl();
			while(true) {
				
				System.out.println("enter 1 to make account");
				System.out.println("enter 2 balance for deposit");
				System.out.println("enter 3 balance for withdraw");
				System.out.println("emter 4 for display details");
				System.out.println("emter 5 for display Balance");
				System.out.println("emter 6 for fund transfer");
				System.out.println("emter 7 to show all account details");
				System.out.println("emter 8 to print all tranaction");
				Scanner sc=new Scanner(System.in);
				int sw=sc.nextInt();
			switch(sw)
			{
			case 1:
				Random r=new Random();
				int accNum=r.nextInt(20);
				System.out.println("enter name:");
				String name=sc.next();
//				System.out.println("enter Accno:");
//				int accno=sc.nextInt();
				System.out.println("enter contact:");
				long contact=sc.nextLong();
				System.out.println("enter balance:");
				double balance=sc.nextDouble();
				Customer c1=new Customer();
				c1.setName(name);
				c1.setContact(contact);
				c1.setBalance(balance);
				c1.setDate(LocalDateTime.now());
				cser.addCustomer(c1);
				System.out.println("welcome to KFC  bank");
				break;
			case 2:
				System.out.println("enter a/c num:");
				int a1=sc.nextInt();
				System.out.println("enter ammount to deposit");
				double amt=sc.nextDouble();
				cser.deposit(a1,amt);
				break;
			case 3:
				System.out.println("enter a/c num:");
				int a2=sc.nextInt();
				System.out.println("enter ammount to withdraw");
				double amt1=sc.nextDouble();
				cser.withdraw(a2,amt1);
				break;
				
			case 4:
				System.out.println("enter a/c num:");
				int a3=sc.nextInt();
				cser.displayDetails(a3);
				break;
			case 5:
				System.out.println("enter a/c num:");
				int a4=sc.nextInt();
				cser.showbalance(a4);
				break;
				
			case 6:
				System.out.println("enter a/c no from which you want to transfer:");
				int a5=sc.nextInt();
				System.out.println("enter a/c no to whom you want to transfer:");
				int a6=sc.nextInt();
				System.out.println("enter ammount to be transfer:");
				double amt2=sc.nextDouble();
				cser.fundTransfer(a5, a6, amt2);
				break;
				
			case 7:
				cser.accountdetails();
				break;
			case 8:
				System.out.println("enter a/c no to print all the transactions:");
				int a7=sc.nextInt();
				cser.printTransactions(a7);
				break;
	}

}
}
}