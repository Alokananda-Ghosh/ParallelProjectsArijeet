package com.cg.service;

import com.cg.bean.Customer;
import com.cg.pl.CustomerDaoImpl;
import com.cg.pl.ICustomerDao;


public class CustomerServiceImpl implements ICustomerService {

	ICustomerDao cdao=new CustomerDaoImpl();
	@Override
	public void addCustomer(Customer c) {
		
		cdao.addCustomer(c);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayDetails(int AccNum) {
		
		cdao.displayDetails(AccNum);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deposit(int AccNum,double x) {
		
		cdao.deposit(AccNum,x);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw(int AccNum,double x) {
		
		cdao.withdraw(AccNum,x);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showbalance(int AccNum) {
		
		cdao.showbalance(AccNum);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer(int accno1, int accno2, double amt) {
		
		cdao.fundTransfer(accno1, accno2, amt);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void accountdetails() {
		
		cdao.accountDetails();
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTransactions(int AccNum) {
		
		cdao.printTransaction(AccNum);
		// TODO Auto-generated method stub
		
	}

}
