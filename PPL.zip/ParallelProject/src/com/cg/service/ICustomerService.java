package com.cg.service;

import com.cg.bean.Customer;

public interface ICustomerService {
	
	public void addCustomer(Customer c);
	public void showbalance(int AccNum);
	public void displayDetails(int AccNum);
	public void accountdetails();
	public void fundTransfer(int accno1,int accno2,double amt);
	void withdraw(int AccNum, double x);
	void deposit(int AccNum, double x);
	public void printTransactions(int AccNum);

}
