package com.cg.pl;

import com.cg.bean.Customer;

public interface ICustomerDao {
	
	
	public void addCustomer(Customer c);
	public void displayDetails(int AccNum);
	public void deposit(int AccNum,double x);
	public void showbalance(int AccNum);
	public void fundTransfer(int accno1,int accno2,double amt);
	public void withdraw(int AccNum,double x);
	public void accountDetails();
	public void printTransaction(int AccNo);
	

}
