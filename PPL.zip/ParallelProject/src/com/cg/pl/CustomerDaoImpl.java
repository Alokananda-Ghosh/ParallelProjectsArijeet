package com.cg.pl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.cg.bean.Customer;
import com.cg.bean.Transaction;

public class CustomerDaoImpl implements ICustomerDao {

	HashMap<Integer,Customer> hm=new HashMap<>();

	@Override
	public void addCustomer(Customer c) {
		
		hm.put(c.getAccNum(),c);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayDetails(int AccNum) {
		
		System.out.println(hm.get(AccNum));

//	Set<Integer> s=hm.keySet();
//	Iterator<Integer> it=s.iterator();
//	while(it.hasNext())
//	{
//		Integer i=it.next();
//		System.out.println(hm.get(i));
//		}
		
		// TODO Auto-generated method stub
		
	}
	
	public void deposit(int AccNum, double x)
	{
		double b=hm.get(AccNum).getBalance();
		hm.get(AccNum).setBalance(b+x);
		System.out.println("your deposite has made");
		
		Transaction t=new Transaction();
		t.setAmount(x);
		t.setDate(LocalDateTime.now());
		t.setType("Deposited");
		//System.out.println(t);
		hm.get(AccNum).setTrans(t);
		
		
	}

	@Override
	public void withdraw(int AccNum,double x) {
		
		double b=hm.get(AccNum).getBalance();
		hm.get(AccNum).setBalance(b-x);
		
			System.out.println("your withdrawl has made");
			
			
//			Customer c1=hm.get(AccNum);
//			long bal=c1.getBalance();
//			c1.
			
			Transaction t=new Transaction();
			t.setAmount(x);
			t.setDate(LocalDateTime.now());
			t.setType("Withdrawn");
			//System.out.println(t);
			
			hm.get(AccNum).setTrans(t);
		}

	@Override
	public void showbalance(int AccNum) {
		
		double b1=hm.get(AccNum).getBalance();
		System.out.println("the balance in the given a/c is:"+b1);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer(int accno1, int accno2, double amt) {
		
//		Customer a=hm.get(accno1);
//		Customer b=hm.get(accno2);
//		
//		double c=a.getBalance()-amt;
//		a.setBalance(c);
//		
//		
//	   double d=b.getBalance()+amt;
//	   b.setBalance(d);
		
	   

		withdraw(accno1, amt);
		deposit(accno2, amt);
		System.out.println("Funds have been transferred!!");
		
		
	}

	@Override
	public void accountDetails() {
		
		Set<Integer> s=hm.keySet();
		Iterator<Integer> it=s.iterator();
		while(it.hasNext())
	{
		Integer i=it.next();
		System.out.println(hm.get(i));
		}
		
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTransaction(int AccNo) {
		
		
		System.out.println(hm.get(AccNo).getTrans());
		
	}
		
		// TODO Auto-generated method stub
		
	}


