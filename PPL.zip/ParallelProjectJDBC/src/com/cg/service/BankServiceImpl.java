package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.Bank;
import com.cg.pl.BankDaoImpl;
import com.cg.pl.IBankDao;

public class BankServiceImpl implements IBankService {
	IBankDao bdao=new BankDaoImpl();
	@Override
	public void addCustomer(Bank b) throws ClassNotFoundException, SQLException {
		
		bdao.addCustomer(b);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deposit(int AccNum, double bal) throws ClassNotFoundException, SQLException {
		
		bdao.deposit(AccNum, bal);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showbalance(int AccNum) throws ClassNotFoundException, SQLException {
		
		bdao.showbalance(AccNum);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer(int accno1, int accno2, double amt) throws ClassNotFoundException, SQLException {
		
		bdao.fundTransfer(accno1, accno2, amt);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw(int AccNum, double bal) throws ClassNotFoundException, SQLException {
		
		bdao.withdraw(AccNum, bal);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void accountDetails() throws ClassNotFoundException, SQLException {
		
		bdao.accountDetails();
		// TODO Auto-generated method stub
		
	}
	@Override
	public void printTransaction(Long AccNo) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		bdao.printTransaction(AccNo);
	}

	@Override
	public void displayDetails(Long Accno) throws ClassNotFoundException, SQLException {
		
		bdao.displayDetails(Accno);
		// TODO Auto-generated method stub
		
	}

//	

}
