package com.cg.ui;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;

import com.cg.bean.Bank;
import com.cg.service.BankServiceImpl;
import com.cg.service.IBankService;

public class TestBank {

		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			
			IBankService bser=new BankServiceImpl();
			
			
				while(true) {
					System.out.println("WELCOME TO SARKAR BANK\n");
					System.out.println("Enter 1 to make account\n");
					System.out.println("Enter 2 balance for deposit\n");
					System.out.println("Enter 3 balance for withdraw\n");
					System.out.println("Enter 4 for display details\n");
					System.out.println("Enter 5 for display Balance\n");
					System.out.println("Enter 6 for fund transfer\n");
					System.out.println("Enter 7 to show all account details\n");
					System.out.println("Enter 8 to print all tranaction\n");
					System.out.println("Enter 9 for exit");
					Scanner sc=new Scanner(System.in);
					int sw=sc.nextInt();
				switch(sw)
				{
				case 1:
					//Random r=new Random();
					//int accNum=r.nextInt(20);
					
//					System.out.println("enter Accno:");
//					long accno=sc.nextLong();
//					String acc=accno+"";
//					String regEx="[0-9]{6}";
//					while(!(acc.matches(regEx)))
//					{
//						System.out.println("please enter again");
//						 accno=sc.nextLong();
//						 acc=accno+"";
//					}
					System.out.println("enter name:");
					String name=sc.next();
					
					System.out.println("enter contact:");
					long contact=sc.nextLong();
					
					String mob=contact+"";
					String regEx1="(91|0)?[6-9][0-9]{9}";
					while(!(mob.matches(regEx1)))
					{
						System.out.println("please enter again");
						 contact=sc.nextLong();
						 mob=contact+"";
					}
					
					System.out.println("enter balance:");
					double balance=sc.nextDouble();
					
					System.out.println("enter Emailid:");
					String email=sc.next();
					String regEx2="[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]{2,})+";
						while(!(email.matches(regEx2)))
					{
						System.out.println("please enter again");
						 email=sc.next();
						
					}
					Bank b1 =new Bank();
					//b1.setAccNum(accno);
					b1.setName(name);
					b1.setContact(contact);
					b1.setBalance(balance);
					b1.setEmail(email);
					bser.addCustomer(b1);
					System.out.println("welcome to KFC  bank");
					break;
					
					
				case 2:
					System.out.println("enter a/c num:");
					int a1=sc.nextInt();
					System.out.println("enter ammount to deposit");
					double amt=sc.nextDouble();
					bser.deposit(a1,amt);
					break;
				case 3:
					System.out.println("enter a/c num:");
					int a2=sc.nextInt();
					System.out.println("enter ammount to withdraw");
					double amt1=sc.nextDouble();
					bser.withdraw(a2,amt1);
					break;
					
					
				case 4:
					System.out.println("enter a/c num:");
					Long a3=sc.nextLong();
					bser.displayDetails(a3);
					break;
					
				case 5:
					System.out.println("enter a/c num:");
					int a4=sc.nextInt();
					bser.showbalance(a4);
					break;
					
				case 6:
					System.out.println("enter a/c no from which you want to transfer:");
					int a5=sc.nextInt();
					System.out.println("enter a/c no to whom you want to transfer:");
					int a6=sc.nextInt();
					System.out.println("enter ammount to be transfer:");
					double amt2=sc.nextDouble();
					bser.fundTransfer(a5, a6, amt2);
					break;
					
				case 7:
					bser.accountDetails();
					break;
				case 8:
					System.out.println("enter a/c no to print all the transactions:");
					Long a7=sc.nextLong();
					bser.printTransaction(a7);
					break;
				case 9:
					System.exit(0);
					break;
					
				}

				}
				
		}

}


