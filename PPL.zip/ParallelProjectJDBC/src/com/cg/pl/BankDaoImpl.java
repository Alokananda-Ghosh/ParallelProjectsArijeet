package com.cg.pl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.Bank;

public class BankDaoImpl implements IBankDao {
	private Connection con = null;
	private PreparedStatement ps = null;

	public void getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "system";
		String pass = "Capgemini123";
		con = DriverManager.getConnection(url, user, pass);
	}

	@Override
	public void addCustomer(Bank b) throws ClassNotFoundException, SQLException {

		getConnection();
		ps = con.prepareStatement("insert into Bank values(accno_seq.nextval,?,?,?,?)");
		//ps.setLong(1,b.getAccNum());
		ps.setString(1,b.getName());
		ps.setLong(2, b.getContact());
		ps.setDouble(3,b.getBalance());
		ps.setString(4,b.getEmail());
		ps.executeUpdate();
		
		
		ps = con.prepareStatement("select * from bank where name=?");
		ps.setString(1,b.getName());
		ResultSet rs=ps.executeQuery();
		rs.next();
		int accno=rs.getInt(1);
		System.out.println("Account created....and your a/c no is:"+accno);
		
		con.close();
	}

	public void deposit(int AccNum, double bal) throws ClassNotFoundException, SQLException {

		getConnection();
		ps = con.prepareStatement("select balance from bank  where accnum= " + AccNum);
		ResultSet rs = ps.executeQuery();
		ps = con.prepareStatement("update Bank set balance=? where accnum=" + AccNum);
		rs.next();
		double b = rs.getDouble(1) + bal;
		ps.setDouble(1, b);
		ps.executeUpdate();
		System.out.println("Deposited");
		
	
		con.close();
		putTransaction(AccNum, "Credited", bal, b);
	}

	@Override
	public void showbalance(int AccNum) throws ClassNotFoundException, SQLException {

		getConnection();
		ps = con.prepareStatement("select balance from bank  where accnum= " + AccNum);
		ResultSet rs = ps.executeQuery();
		rs.next();
		{
			System.out.println("Balance:..." + rs.getDouble(1));
		}

		// TODO Auto-generated method stub

	}

	@Override
	public void fundTransfer(int accno1, int accno2, double amt) throws ClassNotFoundException, SQLException {

		withdraw(accno1, amt);
		deposit(accno2, amt);
		System.out.println("Funds have been transferred!!");

		// TODO Auto-generated method stub

	}

	@Override
	public void withdraw(int AccNum, double bal) throws ClassNotFoundException, SQLException {

		getConnection();
		ps = con.prepareStatement("select balance from bank  where accnum= " + AccNum);
		ResultSet rs = ps.executeQuery();
		ps = con.prepareStatement("update Bank set balance=? where accnum=" + AccNum);
		rs.next();
		double b = rs.getDouble(1)-bal;
		ps.setDouble(1, b);
		ps.executeUpdate();
		System.out.println("Withdrawn");
		con.close();
		putTransaction(AccNum, "Debited", bal, b);
		// TODO Auto-generated method stub

	}

	@Override
	public void accountDetails() throws ClassNotFoundException, SQLException {

		getConnection();
		ps = con.prepareStatement("select * from Bank");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			System.out.println(rs.getLong(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getLong(3));
			System.out.println(rs.getDouble(4));
			System.out.println(rs.getString(5));

		}
		con.close();

	}

	@Override
	public void printTransaction(Long AccNo) throws ClassNotFoundException, SQLException {

		getConnection();
		ps = con.prepareStatement("select * from transaction where accno=" + AccNo);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			System.out.println(rs.getDouble(2) + " \t" + rs.getDate(3) + " \t" + rs.getDouble(4) + " \t" + rs.getString(5));
		}
		con.close();

		// TODO Auto-generated method stub

	}

	public void displayDetails(Long AccNo) throws ClassNotFoundException, SQLException {

		getConnection();
		ps = con.prepareStatement("select * from bank where accnum=" + AccNo);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			System.out.println(rs.getLong(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getLong(3));
			System.out.println(rs.getDouble(4));
			System.out.println(rs.getString(5));

		}
		con.close();

	}

	public void putTransaction(long acc, String msg, double bal, double b) throws ClassNotFoundException, SQLException {

		getConnection();
		ps = con.prepareStatement("insert into transaction values(?,?,?,?,?)");
		ps.setLong(1, acc);
		ps.setDouble(2, bal);
		ps.setDate(3, Date.valueOf(java.time.LocalDate.now()));
		ps.setDouble(4, b);
		ps.setString(5, msg);
		ps.executeUpdate();
		con.close();
		// TODO Auto-generated method stub

	}

}
