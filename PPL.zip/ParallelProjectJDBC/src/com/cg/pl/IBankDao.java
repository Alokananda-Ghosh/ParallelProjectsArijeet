package com.cg.pl;

import java.sql.SQLException;

import com.cg.bean.Bank;

public interface IBankDao {

	
	public void addCustomer(Bank b) throws ClassNotFoundException, SQLException;
	public void deposit(int AccNum,double bal) throws ClassNotFoundException, SQLException;
	public void showbalance(int AccNum) throws ClassNotFoundException, SQLException;
	public void fundTransfer(int accno1,int accno2,double amt) throws ClassNotFoundException, SQLException;
	public void withdraw(int AccNum,double bal) throws ClassNotFoundException, SQLException;
	public void accountDetails() throws ClassNotFoundException, SQLException;
	public void printTransaction(Long AccNo) throws ClassNotFoundException, SQLException;
	public void displayDetails(Long AccNo) throws ClassNotFoundException, SQLException;
	//void putTransaction(double amt,long acc,String msg,double bal) throws ClassNotFoundException, SQLException;
	
}
